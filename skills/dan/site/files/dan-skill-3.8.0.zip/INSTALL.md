# INSTALL — paket skill DAN

Arsip ini berisi agen **DAN** (9 sub-skill + 10 engine, zero-dependency wajib).

## 1. Claude (Claude Code / Projects / skill folder)
Salin folder `skills/dan/` ke lokasi skill Anda, mis.:
```
~/.claude/skills/dan/          # global
<projek>/.claude/skills/dan/   # per-proyek
```
Claude akan membaca `SKILL.md` (orchestrator) dan memuat sub-skill/referensi sesuai kebutuhan
(progressive disclosure). Tidak ada instalasi paket wajib.

## 2. Custom GPT / agent berbasis system-prompt
Tempel isi `skills/dan/AGENT.md` (blok system prompt) ke_instructions_ agent Anda.
Bila runtime mendukung file/tools, unggah folder `skills/dan/scripts/` dan izinkan eksekusi
Python; engine dapat dipanggil sebagai tools.

## 3. Runtime berbasis kode (LangChain / n8n / runtime lain)
Tambahkan `skills/dan/scripts/` ke `sys.path`, lalu panggil engine sebagai fungsi:
```python
import sys; sys.path.insert(0, "path/ke/skills/dan/scripts")
import dan_analytics, make_infographic, project_monitor, arch_advisor, arch_design
```
Semua engine punya `main(argv)` dan bisa dijalankan sebagai CLI (`python3 <engine> --help`).

## 4. Dependensi
- Wajib: **tidak ada** (stdlib Python 3.8+).
- Opsional: `pip install -r skills/dan/scripts/requirements.txt`
  (openpyxl utk XLSX · networkx+scipy utk verifikasi graph · Pillow utk fit_asset).

## 5. Verifikasi pasca-install
```bash
cd skills/dan/scripts
python3 _test_all.py        # wajib: 0 gagal
python3 _check_refs.py      # wajib: 0 referensi hilang
```

## 6. Integritas
Cocokkan `manifest.json` (sha256 per file) bila Anda butuh memastikan arsip tidak berubah:
```bash
python3 - <<'PY'
import hashlib, json, os
m = json.load(open("manifest.json"))
bad = [f["path"] for f in m["files"]
       if os.path.exists(f["path"]) and
       hashlib.sha256(open(f["path"], "rb").read()).hexdigest() != f["sha256"]]
print("utuh" if not bad else f"berubah: {bad}")
PY
```
