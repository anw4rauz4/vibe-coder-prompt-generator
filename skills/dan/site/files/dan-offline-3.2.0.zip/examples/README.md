# Basis Contoh Sektor — mulai cepat dengan konteks industri Anda

Tiga sektor siap pakai, masing-masing berisi **data dummy realistis** (`campaign.csv`)
+ **brief** (konteks, audiens, langkah pertama, jebakan khas). Skema kolom sama dengan
yang dikenali `dan_analytics.py` (alias ID/EN), jadi semua engine langsung jalan.

| Sektor | Folder | Ciri data | Fokus belajar |
|---|---|---|---|
| F&B kedai kopi | `fnb/` | channel delivery + WA broadcast | margin vs diskon, heatmap jam |
| Fashion live-selling | `fashion/` | TikTok Shop/Shopee dominan | funnel halaman produk, retur |
| Jasa B2B (ERP) | `b2b/` | konversi = SQL, nilai besar | biaya-per-SQL, siklus panjang |

## Cara pakai (3 menit)
```bash
cd skills/dan/scripts
python3 dan_analytics.py ../../../examples/fnb/campaign.csv --out /tmp/x.json --report /tmp/x.md
python3 make_infographic.py /tmp/x.json --out /tmp/x.html
python3 budget_sim.py --analysis /tmp/x.json --shift 20 --out /tmp/x_sim.md
```
Ganti `fnb` dengan sektor Anda; baca `brief.md` dulu untuk tahu apa yang harus dicari.

## Menambah sektor sendiri
1. Salin salah satu folder; ganti `campaign.csv` dengan ekspor platform Anda
   (kolom bebas asal bermakna sama — lihat alias di sub-skill 01).
2. Tulis `brief.md`: konteks, margin, tujuan kuartal, audiens, 3 jebakan khas.
3. Jalankan `run_cases.py`-style check: analisa → infografik → guard, pastikan lolos.

## Catatan kejujuran data
Angka di folder ini **dummy untuk latihan**, bukan benchmark industri. Untuk keputusan
nyata, pakai data Anda dan jalankan `claim_audit.py` pada laporan sebelum dibagikan.
