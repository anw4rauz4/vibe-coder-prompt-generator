# Brief Contoh — Jasa B2B (vendor ERP/manufaktur)

**Konteks:** penjualan konsultatif, siklus 60–120 hari, nilai kontrak Rp150–300 jt.
Tujuan: perbanyak SQL berkualitas, bukan lead sebanyak-banyaknya.
**Audiens:** CFO/kepala produksi perusahaan manufaktur 100–1000 karyawan.
**Data:** `campaign.csv` (2 minggu, 5 channel; konversi = SQL/demo terjadwal).

## Langkah pertama yang disarankan (urutan)
1. `python3 skills/dan/scripts/dan_analytics.py examples/b2b/campaign.csv \
   --out /tmp/b2b.json --report /tmp/b2b.md`
2. Nilai channel dengan biaya-per-SQL & pipeline-per-Rp, bukan CTR (CTR tinggi di
   LinkedIn belum tentu SQL murah).
3. `python3 skills/dan/scripts/client_report.py --analysis /tmp/b2b.json \
   --nama "Vendor ERP" --period "2 minggu"` untuk laporan ke direksi.
4. Susun nurture: sequence email + webinar bulanan (sub-skill 02 funnel consideration).
5. Buat skor lead sederhana (firmografi + engagement) sebelum menambah budget iklan.

## Jebakan khas sektor ini
- Konversi kecil (puluhan) → interval statistik lebar; jangan ganti strategi tiap minggu.
- Attribution last-click menyesatkan: webinar & konten bekerja di awal funnel.
- Sales capacity terbatas: lead melebihi kapasitas follow-up = buang budget.
