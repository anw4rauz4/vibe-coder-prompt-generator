# Brief Contoh — Fashion (brand lokal, live-selling)

**Konteks:** brand ready-to-wear wanita; penjualan utama via TikTok Shop + Shopee.
Margin kotor ±55%. Tujuan: kurangi biaya akuisisi & naikkan repeat purchase 90 hari.
**Audiens:** wanita 18–34, interest modest-wear & kantor-casual.
**Data:** `campaign.csv` (2 minggu, 5 channel).

## Langkah pertama yang disarankan (urutan)
1. `python3 skills/dan/scripts/dan_analytics.py examples/fashion/campaign.csv \
   --out /tmp/fsh.json --report /tmp/fsh.md`
2. Periksa funnel: impresi→klik sehat tetapi klik→konversi? (khas: masalah halaman
   produk/ukuran, bukan iklan).
3. `python3 skills/dan/scripts/make_infographic.py /tmp/fsh.json --theme light`
4. Rencanakan seri live: kalender konten (templates/content-calendar.csv) + storyboard
   struktur `demo_produk` untuk live-selling (sub-skill 04/18).
5. Uji ukuran/size-chart di halaman produk sebagai A/B utama (sub-skill 02).

## Jebakan khas sektor ini
- Return rate tinggi membuat ROAS semu — hitung revenue bersih setelah retur.
- Live-selling menumpuk konversi di jam tertentu → jangan nilai CPA harian tanpa konteks.
- Stok habis saat iklan jalan = biaya terbuang; sinkronkan budget dengan forecast stok.
