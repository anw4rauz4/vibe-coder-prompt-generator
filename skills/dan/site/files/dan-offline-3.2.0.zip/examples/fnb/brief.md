# Brief Contoh — F&B (kedai kopi multi-cabang)

**Konteks:** 4 cabang + delivery online. Margin kotor ±68%. Tujuan kuartal:
naikkan repeat order member & kurangi ketergantungan pada diskon platform.
**Audiens:** pekerja 22–40 radius 3 km per cabang + member aplikasi.
**Data:** `campaign.csv` (2 minggu, 5 channel).

## Langkah pertama yang disarankan (urutan)
1. `python3 skills/dan/scripts/dan_analytics.py examples/fnb/campaign.csv \
   --out /tmp/fnb.json --report /tmp/fnb.md`
2. Baca: channel mana ROAS-nya di atas break-even (1 ÷ 0,68 ≈ 1,47x)?
   (Petunjuk jawaban: WhatsApp Broadcast & TikTok biasanya unggul; Instagram awareness.)
3. `python3 skills/dan/scripts/budget_sim.py --analysis /tmp/fnb.json --shift 20`
4. Buat infografik untuk rapat cabang: `make_infographic.py /tmp/fnb.json`.
5. Konten: storyboard struktur `hook_story_offer` untuk promo member (sub-skill 04/18).

## Jebakan khas sektor ini
- Revenue platform sudah dipotong komisi → bandingkan dengan revenue DPOS, bukan GMV.
- Jam ramai vs sepi: pakai heatmap jam (sub-skill 03) untuk jadwal promo & staffing.
- Diskon besar menaikkan CVR tapi merusak margin — selalu lihat profit, bukan omzet.
