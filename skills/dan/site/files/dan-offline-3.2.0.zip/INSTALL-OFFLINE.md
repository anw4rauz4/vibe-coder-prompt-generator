# INSTALL OFFLINE — mesin tanpa akses internet & tanpa pip

## Bila python3 sudah ada (mayoritas kasus)
1. Ekstrak bundle ini ke folder mana pun, mis. `D:\dan` atau `/opt/dan`.
2. Verifikasi: `python3 dan.pyz list`  (Windows: `py dan.pyz list`).
3. Mulai: `python3 dan.pyz demo` lalu `python3 dan.pyz init`.
   Tidak ada `pip install` apa pun: seluruh engine stdlib-only.

## Bila python3 BELUM ada
- **Windows**: unduh sekali (di mesin berinternet) "Windows embeddable package"
  python.org → ekstrak → taruh `dan.pyz` di dalamnya → jalankan
  `python.exe dan.pyz list`. Tidak perlu installer/admin.
- **Linux**: `apt/dnf/yum install python3` dari mirror lokal/repo offline, atau
  salin binary python3 + lib standar dari mesin sejenis.
- **macOS**: gunakan python3 bawaan Xcode CLT, atau python.org pkg offline.

## Memakai sebagai skill di AI lokal
- VS Code: buka folder bundle di VS Code; `.vscode/` tidak ikut dalam bundle demi
  keamanan — salin dari `adapters/vscode/dot_vscode/` bila diinginkan.
- Runtime lain: tempel `docs/`SYSTEM_PROMPT` dari adapters/SYSTEM_PROMPT.txt.

## Verifikasi integritas
Bandingkan sha256 `dan.pyz` dengan yang tercatat di `manifest-bundle.json`.
